#include "deadlybarrier.h"

DeadlyBarrier::DeadlyBarrier()
{

}

#ifndef DEADLYBARRIER_H
#define DEADLYBARRIER_H


class DeadlyBarrier
{
public:
    DeadlyBarrier();
};

#endif // DEADLYBARRIER_H

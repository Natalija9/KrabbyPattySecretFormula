#include "slowingbarrier.h"

SlowingBarrier::SlowingBarrier()
{

}

#ifndef SLOWINGBARRIER_H
#define SLOWINGBARRIER_H


class SlowingBarrier
{
public:
    SlowingBarrier();
};

#endif // SLOWINGBARRIER_H

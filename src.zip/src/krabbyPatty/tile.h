#ifndef TILE_H
#define TILE_H
#include "item.h"

class Tile : public Item
{
public:
    Tile(qreal playerWidth);
};

#endif // TILE_H
